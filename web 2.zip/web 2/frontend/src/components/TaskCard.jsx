import React from 'react';

const TaskCard = ({ task, onUpdateStatus, onDelete, onEdit }) => {
    const getPriorityColors = (priority) => {
        switch (priority) {
            case 'low': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
            case 'medium': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
            case 'high': return 'bg-orange-500/10 text-orange-400 border-orange-500/20';
            case 'urgent': return 'bg-red-500/10 text-red-400 border-red-500/20';
            default: return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
        }
    };

    const getStatusButtonConfig = (status) => {
        if (status === 'todo') return { label: "Devam'a taşı", next: 'in-progress', color: 'text-blue-400 hover:text-blue-300' };
        if (status === 'in-progress') return { label: "Tamamla", next: 'done', color: 'text-green-400 hover:text-green-300' };
        return { label: "Geri Al", next: 'in-progress', color: 'text-orange-400 hover:text-orange-300' };
    };

    const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'done';
    const btnConfig = getStatusButtonConfig(task.status);

    return (
        <div className={`p-4 rounded-xl mb-3 shadow-lg bg-dark-800 border ${isOverdue ? 'border-red-500/50' : 'border-dark-700'} relative group transition-all duration-200 hover:-translate-y-1 hover:shadow-xl`}>

            {/* Actions (Edit/Delete) - visible on hover */}
            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                <button onClick={() => onEdit(task)} className="p-1.5 text-slate-400 hover:text-blue-400 bg-dark-900 rounded-md">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9" /><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" /></svg>
                </button>
                <button onClick={() => onDelete(task._id)} className="p-1.5 text-slate-400 hover:text-red-400 bg-dark-900 rounded-md">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18" /><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" /><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" /></svg>
                </button>
            </div>

            <h3 className={`font-semibold text-base pr-12 ${task.status === 'done' ? 'text-slate-500 line-through' : 'text-white'}`}>
                {task.title}
            </h3>

            <div className="flex flex-wrap gap-2 mt-3">
                {/* Priority Badge */}
                <span className={`px-2 py-0.5 rounded-md text-xs font-medium border ${getPriorityColors(task.priority)}`}>
                    {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                </span>

                {/* Tags */}
                {task.tags && task.tags.map(tag => (
                    <span key={tag} className="px-2 py-0.5 rounded-md text-xs font-medium bg-purple-500/10 text-purple-400 border border-purple-500/20">
                        {tag}
                    </span>
                ))}
            </div>

            {isOverdue && (
                <div className="mt-3 text-xs font-semibold text-red-400 flex items-center">
                    <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    Gecikmiş Görev
                </div>
            )}

            {/* Footer / Move Button */}
            <div className="mt-4 flex justify-between items-center border-t border-dark-700/50 pt-2">
                <div className="text-xs text-slate-400 flex items-center">
                    <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                    {task.dueDate ? new Date(task.dueDate).toLocaleDateString('tr-TR') : 'Tarih Yok'}
                </div>

                <button
                    onClick={() => onUpdateStatus(task._id, btnConfig.next)}
                    className={`text-xs font-medium transition-colors ${btnConfig.color} flex items-center`}
                >
                    {btnConfig.label}
                    <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg>
                </button>
            </div>

        </div>
    );
};

export default TaskCard;
