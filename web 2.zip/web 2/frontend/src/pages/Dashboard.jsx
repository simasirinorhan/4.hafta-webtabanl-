import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { LayoutDashboard, Users, UserCircle, LogOut, Code, ShieldCheck, Database, Layers } from 'lucide-react';
import api from '../utils/api';

const Dashboard = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const res = await api.get('/users');
                setUsers(res.data.data);
            } catch (error) {
                console.error('Failed to fetch users', error);
            } finally {
                setLoading(false);
            }
        };
        fetchUsers();
    }, []);

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <div className="min-h-screen bg-dark-900 pb-12">
            {/* Navbar */}
            <nav className="border-b border-dark-800 bg-dark-900/50 backdrop-blur-md sticky top-0 z-50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16 items-center">
                        <div className="flex items-center space-x-3">
                            <div className="bg-primary-500/10 p-2 rounded-lg text-primary-400">
                                <Layers size={24} />
                            </div>
                            <span className="font-bold text-xl tracking-tight text-white">MERN Arch</span>
                        </div>
                        <div className="flex items-center space-x-6">
                            <Link
                                to="/architecture"
                                className="text-slate-300 hover:text-white flex items-center space-x-2 transition-colors"
                                title="View Architecture"
                            >
                                <Code size={18} />
                                <span className="hidden sm:inline">Architecture</span>
                            </Link>
                            <div className="h-6 w-px bg-dark-700"></div>
                            <div className="flex items-center space-x-3">
                                <UserCircle className="text-slate-400" size={24} />
                                <span className="text-sm font-medium text-slate-200 hidden sm:inline">
                                    {user?.username || 'User'}
                                </span>
                            </div>
                            <button
                                onClick={handleLogout}
                                className="text-slate-400 hover:text-red-400 transition-colors bg-dark-800 hover:bg-dark-700 p-2 rounded-lg"
                                title="Logout"
                            >
                                <LogOut size={18} />
                            </button>
                        </div>
                    </div>
                </div>
            </nav>

            {/* Main Content */}
            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
                <div className="mb-8 animate-fade-in">
                    <h1 className="text-3xl font-bold text-white mb-2">Dashboard</h1>
                    <p className="text-slate-400">Welcome back. Here is an overview of the system.</p>
                </div>

                {/* Stats Section */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                    <div className="glass-card flex items-center p-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
                        <div className="bg-blue-500/10 p-4 rounded-xl text-blue-400 mr-4">
                            <Users size={28} />
                        </div>
                        <div>
                            <p className="text-slate-400 text-sm font-medium">Total Users</p>
                            <h3 className="text-2xl font-bold text-white mt-1">{loading ? '-' : users.length}</h3>
                        </div>
                    </div>

                    <div className="glass-card flex items-center p-6 animate-slide-up" style={{ animationDelay: '0.2s' }}>
                        <div className="bg-green-500/10 p-4 rounded-xl text-green-400 mr-4">
                            <ShieldCheck size={28} />
                        </div>
                        <div>
                            <p className="text-slate-400 text-sm font-medium">Auth Status</p>
                            <h3 className="text-xl font-bold text-white mt-1">Secured (JWT)</h3>
                        </div>
                    </div>

                    <div className="glass-card flex items-center p-6 animate-slide-up" style={{ animationDelay: '0.3s' }}>
                        <div className="bg-purple-500/10 p-4 rounded-xl text-purple-400 mr-4">
                            <Database size={28} />
                        </div>
                        <div>
                            <p className="text-slate-400 text-sm font-medium">Database</p>
                            <h3 className="text-xl font-bold text-white mt-1">Connected</h3>
                        </div>
                    </div>
                </div>

                {/* Users Table */}
                <div className="glass-card p-0 overflow-hidden animate-slide-up" style={{ animationDelay: '0.4s' }}>
                    <div className="p-6 border-b border-dark-700">
                        <h2 className="text-xl font-semibold text-white flex items-center">
                            <LayoutDashboard size={20} className="mr-2 text-primary-400" />
                            Registered Users
                        </h2>
                    </div>

                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-dark-900/50">
                                    <th className="py-4 px-6 text-xs font-semibold text-slate-400 uppercase tracking-wider">User ID</th>
                                    <th className="py-4 px-6 text-xs font-semibold text-slate-400 uppercase tracking-wider">Username</th>
                                    <th className="py-4 px-6 text-xs font-semibold text-slate-400 uppercase tracking-wider">Email</th>
                                    <th className="py-4 px-6 text-xs font-semibold text-slate-400 uppercase tracking-wider">Role</th>
                                    <th className="py-4 px-6 text-xs font-semibold text-slate-400 uppercase tracking-wider">Joined</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-dark-700">
                                {loading ? (
                                    <tr>
                                        <td colSpan="5" className="py-8 text-center text-slate-400">Loading users...</td>
                                    </tr>
                                ) : users.length === 0 ? (
                                    <tr>
                                        <td colSpan="5" className="py-8 text-center text-slate-400">No users found.</td>
                                    </tr>
                                ) : (
                                    users.map((u) => (
                                        <tr key={u._id} className="hover:bg-dark-700/30 transition-colors">
                                            <td className="py-4 px-6 text-sm text-slate-500 font-mono">{u._id.substring(0, 8)}...</td>
                                            <td className="py-4 px-6 text-sm font-medium text-slate-200">
                                                <div className="flex items-center">
                                                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary-500 to-blue-500 flex items-center justify-center text-white font-bold text-xs mr-3">
                                                        {u.username.charAt(0).toUpperCase()}
                                                    </div>
                                                    {u.username}
                                                </div>
                                            </td>
                                            <td className="py-4 px-6 text-sm text-slate-400">{u.email}</td>
                                            <td className="py-4 px-6 text-sm">
                                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${u.role === 'admin'
                                                        ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                                                        : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                                                    }`}>
                                                    {u.role}
                                                </span>
                                            </td>
                                            <td className="py-4 px-6 text-sm text-slate-400">
                                                {new Date(u.createdAt).toLocaleDateString()}
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Dashboard;
