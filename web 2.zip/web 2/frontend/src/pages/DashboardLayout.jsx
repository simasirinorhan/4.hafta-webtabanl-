import React from 'react';
import { Outlet, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LayoutDashboard, LogOut, Code, UserCircle, CheckSquare } from 'lucide-react';

const DashboardLayout = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <div className="min-h-screen bg-dark-900 pb-12">
            {/* Navbar */}
            <nav className="border-b border-dark-800 bg-dark-900/50 backdrop-blur-md sticky top-0 z-50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16 items-center">
                        <div className="flex items-center space-x-3">
                            <div className="bg-primary-500/10 p-2 rounded-lg text-primary-400">
                                <CheckSquare size={24} />
                            </div>
                            <span className="font-bold text-xl tracking-tight text-white hidden sm:block">
                                TaskFlow
                            </span>
                        </div>

                        <div className="flex items-center space-x-6">
                            <Link
                                to="/tasks"
                                className="text-slate-300 hover:text-white flex items-center space-x-2 transition-colors"
                            >
                                <LayoutDashboard size={18} />
                                <span className="hidden sm:inline">Panom</span>
                            </Link>
                            <Link
                                to="/architecture"
                                className="text-slate-300 hover:text-white flex items-center space-x-2 transition-colors"
                                title="View Architecture"
                            >
                                <Code size={18} />
                                <span className="hidden sm:inline">Mimari</span>
                            </Link>
                            <div className="h-6 w-px bg-dark-700"></div>
                            <div className="flex items-center space-x-3">
                                <UserCircle className="text-slate-400" size={24} />
                                <span className="text-sm font-medium text-slate-200 hidden sm:inline">
                                    {user?.username || 'User'}
                                </span>
                            </div>
                            <button
                                onClick={handleLogout}
                                className="text-slate-400 hover:text-red-400 transition-colors bg-dark-800 hover:bg-dark-700 p-2 rounded-lg"
                                title="Logout"
                            >
                                <LogOut size={18} />
                            </button>
                        </div>
                    </div>
                </div>
            </nav>

            {/* Page Content */}
            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
                <Outlet />
            </main>
        </div>
    );
};

export default DashboardLayout;
