import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Server, Database, CodeSquare, Cpu, Layers, Layout, ArrowRight } from 'lucide-react';

const Architecture = () => {
    const steps = [
        {
            id: 1,
            name: 'Client (Frontend)',
            icon: <Layout size={24} className="text-blue-400" />,
            color: 'blue',
            desc: 'React SPA handling UI & State Management'
        },
        {
            id: 2,
            name: 'Controller Layer',
            icon: <CodeSquare size={24} className="text-purple-400" />,
            color: 'purple',
            desc: 'Express routes intercepting HTTP req/res'
        },
        {
            id: 3,
            name: 'Service Layer',
            icon: <Cpu size={24} className="text-pink-400" />,
            color: 'pink',
            desc: 'Business logic & validations executed here'
        },
        {
            id: 4,
            name: 'Repository Layer',
            icon: <Layers size={24} className="text-orange-400" />,
            color: 'orange',
            desc: 'Abstracts database queries / Mongoose models'
        },
        {
            id: 5,
            name: 'Database',
            icon: <Database size={24} className="text-primary-400" />,
            color: 'primary',
            desc: 'MongoDB Data Persistence Layer'
        }
    ];

    return (
        <div className="min-h-screen bg-dark-900 pb-12">
            {/* Header */}
            <div className="border-b border-dark-800 bg-dark-900/50 backdrop-blur-md sticky top-0 z-50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                        <Link to="/" className="p-2 bg-dark-800 hover:bg-dark-700 rounded-lg text-slate-300 transition-colors">
                            <ArrowLeft size={20} />
                        </Link>
                        <h1 className="text-2xl font-bold text-white flex items-center">
                            <Server className="mr-3 text-primary-500" size={24} />
                            System Architecture
                        </h1>
                    </div>
                </div>
            </div>

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
                <div className="text-center max-w-2xl mx-auto mb-16 animate-fade-in">
                    <h2 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-primary-400 mb-4">
                        Layered Architecture Flow
                    </h2>
                    <p className="text-slate-400 text-lg">
                        This visualization demonstrates the strict separation of concerns implemented in our backend Node.js system.
                    </p>
                </div>

                {/* Architecture Diagram area */}
                <div className="relative max-w-5xl mx-auto bg-dark-800/30 rounded-3xl border border-dark-700 p-8 sm:p-12 overflow-hidden">
                    {/* Decorative background grid */}
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:32px_32px]"></div>

                    <div className="relative z-10 hidden md:flex items-center justify-between gap-2 lg:gap-4">
                        {steps.map((step, index) => (
                            <React.Fragment key={step.id}>
                                {/* Node Box */}
                                <div
                                    className={`flex-1 glass-card p-6 text-center transform transition-transform hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(var(--${step.color}-500),0.2)] animate-slide-up group`}
                                    style={{ animationDelay: `${index * 0.15}s` }}
                                >
                                    <div className={`mx-auto w-16 h-16 rounded-full bg-dark-900 border-2 border-${step.color}-500/30 flex items-center justify-center mb-4 group-hover:border-${step.color}-400 transition-colors shadow-lg shadow-${step.color}-500/20`}>
                                        {step.icon}
                                    </div>
                                    <h3 className="text-white font-bold mb-2">{step.name}</h3>
                                    <p className="text-xs text-slate-400 leading-relaxed">{step.desc}</p>
                                </div>

                                {/* Arrow Connector (except after last element) */}
                                {index < steps.length - 1 && (
                                    <div className="flex flex-col items-center animate-fade-in" style={{ animationDelay: `${(index * 0.15) + 0.1}s` }}>
                                        <div className="text-dark-500">
                                            <ArrowRight size={28} className="animate-pulse" />
                                        </div>
                                    </div>
                                )}
                            </React.Fragment>
                        ))}
                    </div>

                    {/* Mobile representation (Vertical) */}
                    <div className="md:hidden space-y-4 relative z-10">
                        {steps.map((step, index) => (
                            <React.Fragment key={step.id}>
                                <div
                                    className="glass-card p-5 flex items-center text-left"
                                >
                                    <div className={`flex-shrink-0 w-12 h-12 rounded-full bg-dark-900 border border-${step.color}-500/30 flex items-center justify-center mr-4`}>
                                        {step.icon}
                                    </div>
                                    <div>
                                        <h3 className="text-white font-bold">{step.name}</h3>
                                        <p className="text-xs text-slate-400 mt-1">{step.desc}</p>
                                    </div>
                                </div>
                                {index < steps.length - 1 && (
                                    <div className="flex justify-center text-dark-500 py-1">
                                        <ArrowLeft className="-rotate-90 animate-pulse" size={24} />
                                    </div>
                                )}
                            </React.Fragment>
                        ))}
                    </div>

                </div>
            </main>
        </div>
    );
};

export default Architecture;
