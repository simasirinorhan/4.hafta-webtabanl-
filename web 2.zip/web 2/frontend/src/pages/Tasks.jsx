import React, { useState, useEffect, useMemo } from 'react';
import { taskAPI } from '../utils/api';
import TaskCard from '../components/TaskCard';
import TaskForm from '../components/TaskForm';
import { Plus, Search, Filter } from 'lucide-react';
import { isToday, isPast } from 'date-fns';

const Tasks = () => {
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingTask, setEditingTask] = useState(null);

    // Filters
    const [searchTerm, setSearchTerm] = useState('');
    const [filterPriority, setFilterPriority] = useState('all');

    const fetchTasks = async () => {
        try {
            setLoading(true);
            const res = await taskAPI.getAll();
            setTasks(res.data.data);
        } catch (error) {
            console.error("Failed to fetch tasks", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchTasks();
    }, []);

    const handleSaveTask = async (taskData) => {
        try {
            if (editingTask) {
                await taskAPI.update(editingTask._id, taskData);
            } else {
                await taskAPI.create(taskData);
            }
            fetchTasks();
            closeForm();
        } catch (error) {
            console.error("Failed to save task", error);
        }
    };

    const handleDeleteTask = async (id) => {
        if (window.confirm('Bu görevi silmek istediğinize emin misiniz?')) {
            try {
                await taskAPI.delete(id);
                setTasks(tasks.filter(t => t._id !== id));
            } catch (error) {
                console.error("Failed to delete task", error);
            }
        }
    };

    const handleUpdateStatus = async (id, newStatus) => {
        try {
            // Optimistic UI Update for snappiness
            setTasks(tasks.map(t => t._id === id ? { ...t, status: newStatus } : t));
            await taskAPI.update(id, { status: newStatus });
        } catch (error) {
            console.error("Failed to update status", error);
            fetchTasks(); // Revert on failure
        }
    };

    const openEditForm = (task) => {
        setEditingTask(task);
        setIsFormOpen(true);
    };

    const closeForm = () => {
        setEditingTask(null);
        setIsFormOpen(false);
    };

    // Derived State (Filtering and Stats)
    const filteredTasks = useMemo(() => {
        return tasks.filter(task => {
            const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                (task.description && task.description.toLowerCase().includes(searchTerm.toLowerCase()));
            const matchesPriority = filterPriority === 'all' || task.priority === filterPriority;
            return matchesSearch && matchesPriority;
        });
    }, [tasks, searchTerm, filterPriority]);

    const stats = useMemo(() => {
        const total = tasks.length;
        const completed = tasks.filter(t => t.status === 'done').length;
        const overdue = tasks.filter(t => t.status !== 'done' && t.dueDate && isPast(new Date(t.dueDate)) && !isToday(new Date(t.dueDate))).length;
        const completedToday = tasks.filter(t => t.status === 'done' && isToday(new Date(t.updatedAt))).length;

        return { total, completed, overdue, completedToday };
    }, [tasks]);

    const getColumnTasks = (status) => filteredTasks.filter(t => t.status === status);

    return (
        <div className="max-w-7xl mx-auto">

            {/* 1. Header & Stats Widget */}
            <div className="glass-card mb-6 p-4 flex flex-col md:flex-row items-center justify-between gap-4 animate-fade-in">
                <div className="flex items-center space-x-2">
                    <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-primary-400 uppercase tracking-wider hidden sm:block">
                        DASHBOARD
                    </h1>
                </div>

                <div className="flex flex-wrap gap-3 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
                    <div className="bg-blue-500/10 border border-blue-500/20 px-4 py-2 rounded-xl text-center min-w-[100px]">
                        <p className="text-xs text-blue-400/80 font-medium font-mono uppercase tracking-wider">Toplam</p>
                        <p className="text-2xl font-bold text-blue-400">{stats.total}</p>
                    </div>
                    <div className="bg-green-500/10 border border-green-500/20 px-4 py-2 rounded-xl text-center min-w-[100px]">
                        <p className="text-xs text-green-400/80 font-medium font-mono uppercase tracking-wider">Tamamlanan</p>
                        <p className="text-2xl font-bold text-green-400">{stats.completed}</p>
                    </div>
                    <div className="bg-red-500/10 border border-red-500/20 px-4 py-2 rounded-xl text-center min-w-[100px]">
                        <p className="text-xs text-red-500/80 font-medium font-mono uppercase tracking-wider">Geciken</p>
                        <p className="text-2xl font-bold text-red-500">{stats.overdue}</p>
                    </div>
                    <div className="bg-orange-500/10 border border-orange-500/20 px-4 py-2 rounded-xl text-center min-w-[100px]">
                        <p className="text-xs text-orange-400/80 font-medium font-mono uppercase tracking-wider">Bugün Biten</p>
                        <p className="text-2xl font-bold text-orange-400">{stats.completedToday}</p>
                    </div>
                </div>
            </div>

            {/* 2. Filter Bar */}
            <div className="glass-card mb-6 p-3 flex flex-col sm:flex-row items-center justify-between gap-3 animate-fade-in" style={{ animationDelay: '0.1s' }}>
                <div className="flex flex-1 w-full gap-3">
                    <div className="relative w-full sm:max-w-xs">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Search size={16} className="text-slate-400" />
                        </div>
                        <input
                            type="text"
                            placeholder="Görev ara..."
                            className="input-field pl-10 py-2 text-sm bg-dark-900 focus:bg-dark-800"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>

                    <div className="relative">
                        <select
                            className="input-field py-2 pl-3 pr-8 text-sm appearance-none bg-dark-900 border-dark-600 focus:bg-dark-800 text-slate-300"
                            value={filterPriority}
                            onChange={(e) => setFilterPriority(e.target.value)}
                        >
                            <option value="all">Tüm Öncelikler</option>
                            <option value="urgent">Acil</option>
                            <option value="high">Yüksek</option>
                            <option value="medium">Orta</option>
                            <option value="low">Düşük</option>
                        </select>
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                            <Filter size={14} className="text-slate-500" />
                        </div>
                    </div>
                </div>

                <button onClick={() => setIsFormOpen(true)} className="btn-primary py-2 w-full sm:w-auto flex items-center justify-center">
                    <Plus size={18} className="mr-1.5" />
                    Yeni
                </button>
            </div>

            {/* 3. Kanban Columns */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start animate-fade-in" style={{ animationDelay: '0.2s' }}>

                {/* TODO Column */}
                <div className="bg-dark-800/40 rounded-2xl p-4 border-2 border-orange-500/20">
                    <div className="flex justify-between items-center mb-4 px-2">
                        <h2 className="text-orange-400 font-bold text-lg flex items-center">
                            <span className="text-xl mr-2">📋</span> Yapılacak
                        </h2>
                        <span className="text-orange-500/50 font-bold text-xl">{getColumnTasks('todo').length}</span>
                    </div>
                    <div className="space-y-3 min-h-[200px]">
                        {loading && <div className="text-center py-4"><span className="animate-pulse w-6 h-6 border-2 border-orange-500/40 border-t-orange-500 rounded-full inline-block"></span></div>}
                        {!loading && getColumnTasks('todo').map(task => (
                            <TaskCard
                                key={task._id}
                                task={task}
                                onUpdateStatus={handleUpdateStatus}
                                onDelete={handleDeleteTask}
                                onEdit={openEditForm}
                            />
                        ))}
                        {!loading && getColumnTasks('todo').length === 0 && (
                            <div className="text-slate-500/50 text-center py-8 text-sm border-2 border-dashed border-dark-700 rounded-xl">Görev Yok</div>
                        )}
                    </div>
                </div>

                {/* IN-PROGRESS Column */}
                <div className="bg-dark-800/40 rounded-2xl p-4 border-2 border-blue-500/20">
                    <div className="flex justify-between items-center mb-4 px-2">
                        <h2 className="text-blue-400 font-bold text-lg flex items-center">
                            <span className="text-xl mr-2">🔄</span> Devam Ediyor
                        </h2>
                        <span className="text-blue-500/50 font-bold text-xl">{getColumnTasks('in-progress').length}</span>
                    </div>
                    <div className="space-y-3 min-h-[200px]">
                        {loading && <div className="text-center py-4"><span className="animate-pulse w-6 h-6 border-2 border-blue-500/40 border-t-blue-500 rounded-full inline-block"></span></div>}
                        {!loading && getColumnTasks('in-progress').map(task => (
                            <TaskCard
                                key={task._id}
                                task={task}
                                onUpdateStatus={handleUpdateStatus}
                                onDelete={handleDeleteTask}
                                onEdit={openEditForm}
                            />
                        ))}
                        {!loading && getColumnTasks('in-progress').length === 0 && (
                            <div className="text-slate-500/50 text-center py-8 text-sm border-2 border-dashed border-dark-700 rounded-xl">Görev Yok</div>
                        )}
                    </div>
                </div>

                {/* DONE Column */}
                <div className="bg-dark-800/40 rounded-2xl p-4 border-2 border-green-500/20 opacity-80 transition-opacity hover:opacity-100">
                    <div className="flex justify-between items-center mb-4 px-2">
                        <h2 className="text-green-500 font-bold text-lg flex items-center">
                            <span className="text-xl mr-2">✅</span> Tamamlandı
                        </h2>
                        <span className="text-green-500/50 font-bold text-xl">{getColumnTasks('done').length}</span>
                    </div>
                    <div className="space-y-3 min-h-[200px]">
                        {loading && <div className="text-center py-4"><span className="animate-pulse w-6 h-6 border-2 border-green-500/40 border-t-green-500 rounded-full inline-block"></span></div>}
                        {!loading && getColumnTasks('done').map(task => (
                            <TaskCard
                                key={task._id}
                                task={task}
                                onUpdateStatus={handleUpdateStatus}
                                onDelete={handleDeleteTask}
                                onEdit={openEditForm}
                            />
                        ))}
                        {!loading && getColumnTasks('done').length === 0 && (
                            <div className="text-slate-500/50 text-center py-8 text-sm border-2 border-dashed border-dark-700 rounded-xl">Görev Yok</div>
                        )}
                    </div>
                </div>

            </div>

            {isFormOpen && (
                <TaskForm
                    onSave={handleSaveTask}
                    onClose={closeForm}
                    initialData={editingTask}
                />
            )}
        </div>
    );
};

export default Tasks;
