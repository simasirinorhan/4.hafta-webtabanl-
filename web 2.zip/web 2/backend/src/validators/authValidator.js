const { body } = require('express-validator');

exports.registerValidation = [
    body('username', 'Username is required').not().isEmpty(),
    body('username', 'Username must be at least 3 characters long').isLength({ min: 3 }),
    body('email', 'Please include a valid email').isEmail(),
    body('password', 'Please enter a password with 6 or more characters').isLength({ min: 6 })
];

exports.loginValidation = [
    body('email', 'Please include a valid email').isEmail(),
    body('password', 'Password is required').exists()
];
