const taskService = require('../services/taskService');

class TaskController {
    async getTasks(req, res) {
        try {
            const tasks = await taskService.getTasksByUser(req.user.id, req.query);
            res.status(200).json({ success: true, count: tasks.length, data: tasks });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    }

    async getTask(req, res) {
        try {
            const task = await taskService.getTaskById(req.params.id, req.user.id);
            res.status(200).json({ success: true, data: task });
        } catch (error) {
            // Differentiating between not found and unauthorized could be improved with custom error classes
            const status = error.message.includes('authorized') ? 403 : 404;
            res.status(status).json({ success: false, message: error.message });
        }
    }

    async createTask(req, res) {
        try {
            const task = await taskService.createTask(req.body, req.user.id);
            res.status(201).json({ success: true, data: task });
        } catch (error) {
            res.status(400).json({ success: false, message: error.message });
        }
    }

    async updateTask(req, res) {
        try {
            const task = await taskService.updateTask(req.params.id, req.body, req.user.id);
            res.status(200).json({ success: true, data: task });
        } catch (error) {
            const status = error.message.includes('authorized') ? 403 : 404;
            res.status(status).json({ success: false, message: error.message });
        }
    }

    async deleteTask(req, res) {
        try {
            await taskService.deleteTask(req.params.id, req.user.id);
            res.status(200).json({ success: true, data: {} });
        } catch (error) {
            const status = error.message.includes('authorized') ? 403 : 404;
            res.status(status).json({ success: false, message: error.message });
        }
    }
}

module.exports = new TaskController();
