const express = require('express');
const { getUsers, getUser, deleteUser } = require('../controllers/userController');
const { protect, authorize } = require('../middleware/authMiddleware');

const router = express.Router();

// Apply protection to all user routes
router.use(protect);

router.route('/')
    .get(getUsers);

router.route('/:id')
    .get(getUser)
    .delete(authorize('admin'), deleteUser);

module.exports = router;
