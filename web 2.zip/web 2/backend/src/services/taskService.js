const taskRepository = require('../repositories/taskRepository');

class TaskService {
    async getTasksByUser(userId, filters = {}) {
        // We can handle query params filtering here (e.g. ?status=todo)
        const query = {};
        if (filters.status) query.status = filters.status;
        if (filters.priority) query.priority = filters.priority;

        return taskRepository.findByUser(userId, query);
    }

    async getTaskById(taskId, userId) {
        const task = await taskRepository.findById(taskId);

        if (!task) {
            throw new Error('Task not found');
        }

        // Ensure the task belongs to the user requesting it
        if (task.user.toString() !== userId) {
            throw new Error('Not authorized to access this task');
        }

        return task;
    }

    async createTask(taskData, userId) {
        const data = { ...taskData, user: userId };
        return taskRepository.create(data);
    }

    async updateTask(taskId, updateData, userId) {
        // Verify ownership first
        const task = await taskRepository.findById(taskId);
        if (!task) throw new Error('Task not found');
        if (task.user.toString() !== userId) throw new Error('Not authorized to update this task');

        return taskRepository.update(taskId, updateData);
    }

    async deleteTask(taskId, userId) {
        // Verify ownership first
        const task = await taskRepository.findById(taskId);
        if (!task) throw new Error('Task not found');
        if (task.user.toString() !== userId) throw new Error('Not authorized to delete this task');

        await taskRepository.delete(taskId);
        return { id: taskId };
    }
}

module.exports = new TaskService();
