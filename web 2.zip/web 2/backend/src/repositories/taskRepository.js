const Task = require('../models/Task');

class TaskRepository {
    async findByUser(userId, queryFilters = {}) {
        return Task.find({ user: userId, ...queryFilters }).sort({ createdAt: -1 });
    }

    async findById(taskId) {
        return Task.findById(taskId);
    }

    async create(taskData) {
        return Task.create(taskData);
    }

    async update(taskId, updateData) {
        return Task.findByIdAndUpdate(taskId, updateData, {
            new: true,
            runValidators: true
        });
    }

    async delete(taskId) {
        return Task.findByIdAndDelete(taskId);
    }
}

module.exports = new TaskRepository();
