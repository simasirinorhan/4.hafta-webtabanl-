const User = require('../models/User');

class UserRepository {
    async findByEmail(email) {
        return User.findOne({ email });
    }

    async findByUsername(username) {
        return User.findOne({ username });
    }

    async findById(id) {
        return User.findById(id).select('-password');
    }

    async findAll() {
        return User.find().select('-password');
    }

    async create(userData) {
        return User.create(userData);
    }

    async delete(id) {
        return User.findByIdAndDelete(id);
    }
}

module.exports = new UserRepository();
